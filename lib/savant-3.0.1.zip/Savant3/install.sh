#!/bin/bash
cd `dirname "$0"`

pear channel-add channel.xml
pear install Savant3-3.0.1.tgz
